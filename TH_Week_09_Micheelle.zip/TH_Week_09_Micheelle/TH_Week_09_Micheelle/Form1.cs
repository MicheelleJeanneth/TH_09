﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_Week_09_Micheelle
{
    public partial class Form1 : Form
    {
        bool cek = false;
        DataTable dtitem = new DataTable();
        DataTable dtharga = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }
        int tes = 0;
        int amount = 0;
        int sub = 0;
        private void Form1_Load(object sender, EventArgs e)
        {
            dtitem.Columns.Add("Item Name");
            dtitem.Columns.Add("Quantity");
            dtitem.Columns.Add("Price");
            dtitem.Columns.Add("Total");
            dgv_list.DataSource = dtitem;

            dtharga.Columns.Add("1");
            dtharga.Columns.Add("2");
            dtharga.Columns.Add("3");

            dtharga.Rows.Add(122000, 102000, 115000);
            dtharga.Rows.Add(139000, 125000, 145000);
            dtharga.Rows.Add(96000, 89000, 102000);
            dtharga.Rows.Add(172000, 195000, 189000);
            dtharga.Rows.Add(750000, 900000, 650000);
            dtharga.Rows.Add(255000, 125000, 140000);
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            tes = 0;
            int p1 = 122000;
            int p2 = 102000;
            int p3 = 115000;

            pictureBox1.Image = Properties.Resources.Men_Nature_Forest_T_Shirt;
            pictureBox2.Image = Properties.Resources.Men_Summer_Casual_T_Shirt;
            pictureBox3.Image = Properties.Resources.Men_Summer_Short_Sleeve_Casual_T_Shirts;

            lbl_item1.Text = "Men Nature Forest \nT-Shirt";
            lbl_price1.Text = "Rp. " + p1.ToString("C2").Remove(0, 2).Remove(p1.ToString().Length, 3) + ",-";
            lbl_item2.Text = "Men Summer Casual \nT-Shirt";
            lbl_price2.Text = "Rp. " + p2.ToString("C2").Remove(0, 2).Remove(p2.ToString().Length, 3) + ",-";
            lbl_item3.Text = "Men Summer Short \nSleeve Casual T-Shirts";
            lbl_price3.Text = "Rp. " + p3.ToString("C2").Remove(0, 2).Remove(p3.ToString().Length, 3) + ",-";
            dgv_list.ClearSelection();
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            tes = 1;
            int p1 = 139000;
            int p2 = 125000;
            int p3 = 145000;

            pictureBox1.Image = Properties.Resources.Men_Polo_Shirt_Black;
            pictureBox2.Image = Properties.Resources.Men_Polo_Shirt_White;
            pictureBox3.Image = Properties.Resources.Men_White_Polo_Shirt_Brown;

            lbl_item1.Text = "Men Polo Shirt Black";
            lbl_price1.Text = "Rp. " + p1.ToString("C2").Remove(0, 2).Remove(p1.ToString().Length, 3) + ",-";
            lbl_item2.Text = "Men Polo Shirt White";
            lbl_price2.Text = "Rp. " + p2.ToString("C2").Remove(0, 2).Remove(p2.ToString().Length, 3) + ",-";
            lbl_item3.Text = "Men White Polo Shirt \nBrown";
            lbl_price3.Text = "Rp. " + p3.ToString("C2").Remove(0, 2).Remove(p3.ToString().Length, 3) + ",-";
            dgv_list.ClearSelection();
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            tes = 2;
            int p1 = 96000;
            int p2 = 89000;
            int p3 = 102000;

            pictureBox1.Image = Properties.Resources.Men_Shorts_Outdoor_Casual_Black;
            pictureBox2.Image = Properties.Resources.Men_Shorts_Casual_White;
            pictureBox3.Image = Properties.Resources.Men_Shorts_Casual_Brown;

            lbl_item1.Text = "Men Shorts Outdoor \nCasual Black";
            lbl_price1.Text = "Rp. " + p1.ToString("C2").Remove(0, 2).Remove(p1.ToString().Length, 3) + ",-";
            lbl_item2.Text = "Men Shorts Casual \nWhite";
            lbl_price2.Text = "Rp. " + p2.ToString("C2").Remove(0, 2).Remove(p2.ToString().Length, 3) + ",-";
            lbl_item3.Text = "Men Shorts Casual \nBrown";
            lbl_price3.Text = "Rp. " + p3.ToString("C2").Remove(0, 2).Remove(p3.ToString().Length, 3) + ",-";
            dgv_list.ClearSelection();
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            tes = 3;
            int p1 = 172000;
            int p2 = 195000;
            int p3 = 189000;

            pictureBox1.Image = Properties.Resources.Men_Long_Pants_Casual_Black;
            pictureBox2.Image = Properties.Resources.Men_Long_Pants_Casual_Brown;
            pictureBox3.Image = Properties.Resources.Men_Long_Pants_Casual_Grey;

            lbl_item1.Text = "Men Long Pants \nCasual Black";
            lbl_price1.Text = "Rp. " + p1.ToString("C2").Remove(0, 2).Remove(p1.ToString().Length, 3) + ",-";
            lbl_item2.Text = "Men Long Pants \nCasual Brown";
            lbl_price2.Text = "Rp. " + p2.ToString("C2").Remove(0, 2).Remove(p2.ToString().Length, 3) + ",-";
            lbl_item3.Text = "Men Long Pants \nCasual Grey";
            lbl_price3.Text = "Rp. " + p3.ToString("C2").Remove(0, 2).Remove(p3.ToString().Length, 3) + ",-";
            dgv_list.ClearSelection();
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            tes = 4;
            int p1 = 750000;
            int p2 = 900000;
            int p3 = 650000;

            pictureBox1.Image = Properties.Resources.Men_Casual_Sport_Shoes_Black;
            pictureBox2.Image = Properties.Resources.Men_Casual_Shoes_White;
            pictureBox3.Image = Properties.Resources.Men_Casual_Leather_Shoes_Blue;

            lbl_item1.Text = "Men Casual Sport \nShoes Black";
            lbl_price1.Text = "Rp. " + p1.ToString("C2").Remove(0, 2).Remove(p1.ToString().Length, 3) + ",-";
            lbl_item2.Text = "Men Casual Shoes \nWhite";
            lbl_price2.Text = "Rp. " + p2.ToString("C2").Remove(0, 2).Remove(p2.ToString().Length, 3) + ",-";
            lbl_item3.Text = "Men Casual Leather \nShoes Blue";
            lbl_price3.Text = "Rp. " + p3.ToString("C2").Remove(0, 2).Remove(p3.ToString().Length, 3) + ",-";
            dgv_list.ClearSelection();
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            tes = 5;
            int p1 = 255000;
            int p2 = 125000;
            int p3 = 140000;

            pictureBox1.Image = Properties.Resources.Exquisite_Moon_Necklace;
            pictureBox2.Image = Properties.Resources.Moissanite_Sunflower_Silver_Necklace;
            pictureBox3.Image = Properties.Resources.Sterling_Silver_Bracelet;

            lbl_item1.Text = "Exquisite Moon \nNecklace";
            lbl_price1.Text = "Rp. " + p1.ToString("C2").Remove(0, 2).Remove(p1.ToString().Length, 3) + ",-";
            lbl_item2.Text = "Moissanite Sunflower \nSilver Necklace";
            lbl_price2.Text = "Rp. " + p2.ToString("C2").Remove(0, 2).Remove(p2.ToString().Length, 3) + ",-";
            lbl_item3.Text = "Sterling Silver \nBracelet";
            lbl_price3.Text = "Rp. " + p3.ToString("C2").Remove(0, 2).Remove(p3.ToString().Length, 3) + ",-";
            dgv_list.ClearSelection();
        }

        private void btn_add1_Click(object sender, EventArgs e)
        {
            bool ada = false;
            int a = 0;
            for (int i = 0; i < dtitem.Rows.Count; i++)
            {
                if (lbl_item1.Text == dtitem.Rows[i][0].ToString())
                {
                    ada = true;
                    a = i;
                    break;
                }
            }
            if (ada == true)
            {
                int quantity = Convert.ToInt32(dtitem.Rows[a][1]) + 1;
                int total = (Convert.ToInt32(dtharga.Rows[tes][0]) * quantity);
                string tot = "Rp. " + total.ToString("C2").Remove(0, 2).Remove(total.ToString().Length, 3) + ",-";

                dtitem.Rows[a][1] = quantity.ToString();
                dtitem.Rows[a][3] = tot;
            }
            else
            {
                dtitem.Rows.Add(lbl_item1.Text, "1", lbl_price1.Text, lbl_price1.Text);
            }
            sub = sub + Convert.ToInt32(dtharga.Rows[tes][0]);
            amount = (sub * 10 / 100) + sub;

            txbx_subtotal.Text = "Rp. " + sub.ToString("C2").Remove(0, 2).Remove(sub.ToString().Length, 3) + ",-";
            txbx_total.Text = "Rp. " + amount.ToString("C2").Remove(0, 2).Remove(amount.ToString().Length, 3) + ",-";
            dgv_list.ClearSelection();
        }

        private void btn_add2_Click(object sender, EventArgs e)
        {
            bool ada = false;
            int a = 0;
            for (int i = 0; i < dtitem.Rows.Count; i++)
            {
                if (lbl_item2.Text == dtitem.Rows[i][0].ToString())
                {
                    ada = true;
                    a = i;
                    break;
                }
            }
            if (ada == true)
            {
                int quantity = Convert.ToInt32(dtitem.Rows[a][1]) + 1;
                int total = (Convert.ToInt32(dtharga.Rows[tes][1]) * quantity);
                string tot = "Rp. " + total.ToString("C2").Remove(0, 2).Remove(total.ToString().Length, 3) + ",-";

                dtitem.Rows[a][1] = quantity.ToString();
                dtitem.Rows[a][3] = tot;

            }
            else
            {
                dtitem.Rows.Add(lbl_item2.Text, "1", lbl_price2.Text, lbl_price2.Text);
            }
            sub = sub + Convert.ToInt32(dtharga.Rows[tes][1]);
            amount = (sub * 10 / 100) + sub;

            txbx_subtotal.Text = "Rp. " + sub.ToString("C2").Remove(0, 2).Remove(sub.ToString().Length, 3) + ",-";
            txbx_total.Text = "Rp. " + amount.ToString("C2").Remove(0, 2).Remove(amount.ToString().Length, 3) + ",-";
            dgv_list.ClearSelection();
        }

        private void btn_add3_Click(object sender, EventArgs e)
        {
            bool ada = false;
            int a = 0;
            for (int i = 0; i < dtitem.Rows.Count; i++)
            {
                if (lbl_item3.Text == dtitem.Rows[i][0].ToString())
                {
                    ada = true;
                    a = i;
                    break;
                }
            }
            if (ada == true)
            {
                int quantity = Convert.ToInt32(dtitem.Rows[a][1]) + 1;
                int total = (Convert.ToInt32(dtharga.Rows[tes][2]) * quantity);
                string tot = "Rp. " + total.ToString("C2").Remove(0, 2).Remove(total.ToString().Length, 3) + ",-";

                dtitem.Rows[a][1] = quantity.ToString();
                dtitem.Rows[a][3] = tot;
            }
            else
            {
                dtitem.Rows.Add(lbl_item3.Text, "1", lbl_price3.Text, lbl_price3.Text);
            }
            sub = sub + Convert.ToInt32(dtharga.Rows[tes][2]);
            amount = (sub * 10 / 100) + sub;

            txbx_subtotal.Text = "Rp. " + sub.ToString("C2").Remove(0, 2).Remove(sub.ToString().Length, 3) + ",-";
            txbx_total.Text = "Rp. " + amount.ToString("C2").Remove(0, 2).Remove(amount.ToString().Length, 3) + ",-";
            dgv_list.ClearSelection();
        }

        private void btn_addother_Click(object sender, EventArgs e)
        {
            bool ada = false;
            int a = 0;
            int harga = Convert.ToInt32(txbx_itemprice.Text);
            string har = "Rp. " + harga.ToString("C2").Remove(0, 2).Remove(harga.ToString().Length, 3) + ",-";
            for (int i = 0; i < dtitem.Rows.Count; i++)
            {
                if (txbx_itemname.Text == dtitem.Rows[i][0].ToString() && har == dtitem.Rows[i][2].ToString())
                {
                    ada = true;
                    a = i;
                    break;
                }
            }
            if (ada == true)
            {
                int quantity = Convert.ToInt32(dtitem.Rows[a][1]) + 1;
                int total = (Convert.ToInt32(txbx_itemprice.Text) * quantity);
                string tot = "Rp. " + total.ToString("C2").Remove(0, 2).Remove(total.ToString().Length, 3) + ",-";

                dtitem.Rows[a][1] = quantity.ToString();
                dtitem.Rows[a][2] = har;
                dtitem.Rows[a][3] = tot;
            }
            else
            {
                string tot = "Rp. " + Convert.ToInt32(txbx_itemprice.Text).ToString("C2").Remove(0, 2).Remove(txbx_itemprice.Text.ToString().Length, 3) + ",-";
                dtitem.Rows.Add(txbx_itemname.Text, "1", har, tot);
            }
            sub = sub + Convert.ToInt32(txbx_itemprice.Text);
            amount = (sub * 10 / 100) + sub;

            txbx_subtotal.Text = "Rp. " + sub.ToString("C2").Remove(0, 2).Remove(sub.ToString().Length, 3) + ",-";
            txbx_total.Text = "Rp. " + amount.ToString("C2").Remove(0, 2).Remove(amount.ToString().Length, 3) + ",-";
            dgv_list.ClearSelection();
            txbx_itemname.Text = "";
            txbx_itemprice.Text = "";
            txbx_itemname.Enabled = false;
            txbx_itemprice.Enabled = false;
            pictureBox4.Image = null;
        }

        private void otherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel2.Top = 40;
            panel2.Left = 95;
            panel1.Visible = false;
            panel2.Visible = true;
            dgv_list.ClearSelection();
        }

        private void btn_upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "PNG File (*.png)|*.png|JPEG File (*.jpeg)|*.jpeg|JPG Files (*.jpg)|*.jpg";
            ofd.InitialDirectory = "C:\\";

            ofd.ShowDialog();
            pictureBox4.Image = new Bitmap(ofd.FileName);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;

            if (pictureBox4.Image == null)
            {

            }
            else 
            {
                txbx_itemname.Enabled = true;
                txbx_itemprice.Enabled = true;
            }
        }

        private void txbx_itemprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar))
            {
                if (!char.IsDigit(e.KeyChar))
                {
                    e.Handled = true;
                }
            }
        }

        private void txbx_subtotal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txbx_itemname_TextChanged(object sender, EventArgs e)
        {
            if (txbx_itemname.Text != "" && txbx_itemprice.Text != "")
            {
                btn_addother.Enabled = true;
            }
            else
            {
                btn_addother.Enabled = false;
            }
        }

        private void txbx_itemprice_TextChanged(object sender, EventArgs e)
        {
            if (txbx_itemname.Text != "" && txbx_itemprice.Text != "")
            {
                btn_addother.Enabled = true;
            }
            else
            {
                btn_addother.Enabled = false;
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (cek == true)
            {
                cek = false;

                for (int i = 0; i < dtitem.Rows.Count; i++)
                {
                    if (dtitem.Rows[i][0].ToString() == dgv_list.CurrentRow.Cells[0].Value.ToString()
                        && dtitem.Rows[i][2].ToString() == dgv_list.CurrentRow.Cells[2].Value.ToString())
                    {
                        dtitem.Rows.RemoveAt(i);
                    }
                }
            }

            int c = 0;
            for (int i = 0; i < dtitem.Rows.Count; i++)
            {
                string[] total = dtitem.Rows[i][3].ToString().Split('R','p','.','-',',');
                string b = "";
                for (int j = 0; j < total.Length; j++)
                {
                    b = b + total[j];
                }
                c = c + Convert.ToInt32(b);
            }
            sub = c;
            txbx_subtotal.Text = "Rp. " + c.ToString("C2").Remove(0, 2).Remove(sub.ToString().Length, 3) + ",-";
            c = c + (c * 10 / 100);
            txbx_total.Text = "Rp. " + c.ToString("C2").Remove(0, 2).Remove(sub.ToString().Length, 3) + ",-";

            dgv_list.ClearSelection();
        }

        private void dgv_list_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cek = true;
        }
    }
}
